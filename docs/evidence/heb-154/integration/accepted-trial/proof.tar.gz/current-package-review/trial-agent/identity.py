"""Offline identity verification; no package installation or network discovery."""
import bootstrap
import hashlib,importlib.metadata as md,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def verify_binding():
    lock=json.loads((ROOT/'dependency-identity.json').read_text())
    if sys.version!=lock['python_version']:raise RuntimeError('python_version_mismatch')
    for name,version in lock['dependency_closure'].items():
        if md.version(name)!=version:raise RuntimeError('dependency_version_mismatch')
    for path,wanted in lock['core_source_sha256'].items():
        if hashlib.sha256((ROOT.parent/'corrected-candidate'/path).read_bytes()).hexdigest()!=wanted:
            raise RuntimeError('corrected_core_hash_mismatch')
    if bootstrap.agent_core.CORE_VERSION!=lock['core_version']:raise RuntimeError('core_version_mismatch')
    return lock
