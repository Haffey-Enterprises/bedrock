"""One JSON input file per call. Live state starts only on explicit --initialize."""
import bootstrap
import argparse,asyncio,signal,sys
from pathlib import Path
from readiness import ROOT,Campaign,invoke,encode
from identity import verify_binding
from transport import NativeAnthropic

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('input_file',nargs='?')
    parser.add_argument('--campaign',required=True,help='Existing durable campaign directory inside trial-agent')
    parser.add_argument('--live',action='store_true',help='Operator-authorized direct Anthropic invocation')
    parser.add_argument('--initialize',action='store_true',help='Initialize once after live go; never overwrite')
    args=parser.parse_args()
    if not args.live:parser.error('Live invocation or initialization requires --live; offline tests use run_offline_tests.py')
    if args.initialize:
        if args.input_file:parser.error('Initialize separately, without an input file')
        verify_binding();Campaign.initialize(args.campaign)
        print(encode({'initialized':str(Path(args.campaign).resolve())}));return 0
    if not args.input_file:parser.error('One input file is required')
    try:input_value=Path(args.input_file).read_text(encoding='utf-8')
    except (OSError,UnicodeError):input_value={'input_file_unreadable':True}
    async def go():
        transport=NativeAnthropic()
        task=asyncio.current_task();loop=asyncio.get_running_loop()
        for signum in (signal.SIGINT,signal.SIGTERM):loop.add_signal_handler(signum,task.cancel)
        try:return await invoke(input_value,transport=transport,campaign_dir=args.campaign)
        finally:
            await transport.close()
            for signum in (signal.SIGINT,signal.SIGTERM):loop.remove_signal_handler(signum)
    result=asyncio.run(go());print(encode(result))
    return 0 if result['terminal_disposition']=='success' else 2
if __name__=='__main__':sys.exit(main())
