"""Preserve each first observation and all fixture evidence; never touch live state."""
import os,sys,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PYTEST='/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-164-2026-09-23/linear-client-proof/venv/bin/python'
SDK='/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-25/sdk-proof/venv/lib/python3.14/site-packages'
path=ROOT/'offline-observations';path.mkdir(exist_ok=True)
i=1
while (path/f'run-{i}.txt').exists():i+=1
log=path/f'run-{i}.txt'
env={**os.environ,'PYTHONPATH':str(ROOT.parent/'corrected-candidate/agent_core_pkg/src')+os.pathsep+SDK,'PYTHONDONTWRITEBYTECODE':'1'}
with log.open('x') as out:
    result=subprocess.run([PYTEST,'-m','pytest','-q','-p','no:cacheprovider','--basetemp',str(path/f'fixtures-{i}'),str(ROOT/'tests')],cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT)
print(log.read_text());print('Preserved:',log);sys.exit(result.returncode)
