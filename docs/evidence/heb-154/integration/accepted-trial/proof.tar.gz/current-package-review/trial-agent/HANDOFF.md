# Requirements-readiness trial: offline handoff

The specialist is ready for root's offline review. No real provider request, token-count request, credential access, network request, or live smoke was executed by this builder. All observed execution is synthetic. Model task judgment and endpoint acceptance remain unverified.

The ratified requirements are copied in `contract.md`; the two public development cases are `development-cases.json`. No held-out case or expectation was read. Do not initialize the live campaign until Tad's explicit go. Root owns the overall build/evaluate clock and any timing amendment.

## Run

Qualified runtime:

```sh
TRIAL='/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/trial-agent'
PYTHON='/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-25/sdk-proof/venv/bin/python'
PYTHONDONTWRITEBYTECODE=1 "$PYTHON" "$TRIAL/run_offline_tests.py"
```

That command uses the existing pytest interpreter, appends the qualified SDK site-packages, and prepends the corrected core source. Every run gets a new `offline-observations/run-N.txt` and `fixtures-N/`; prior failures and JSONL observations stay intact. It never creates live state.

Only after Tad's live go, root supplies `ANTHROPIC_API_KEY` in the child environment and runs:

```sh
PYTHONDONTWRITEBYTECODE=1 "$PYTHON" "$TRIAL/cli.py" --live --initialize --campaign "$TRIAL/live-campaign"
PYTHONDONTWRITEBYTECODE=1 "$PYTHON" "$TRIAL/cli.py" --live --campaign "$TRIAL/live-campaign" "$TRIAL/dev-complete.json"
```

Review that first result together before the next input. The next public input is `dev-vague.json`. Root controls held-out input paths and semantic acceptance. The checker stops its campaign on any mechanical failure, unresolved usage, interrupted invocation or persistence failure. Root must also stop on any semantic mismatch against the independently frozen expectations; the specialist cannot judge its own semantic correctness. Do not reset state or rerun a failed live case. Initialization refuses an existing campaign journal. Human pauses consume the fixed fifteen-minute campaign clock.

A valid input is one UTF-8 JSON object per file; no additional keys. stdout is one return envelope. Exit 0 means mechanically successful task judgment; exit 2 means terminal failure. Startup/CLI argument errors are usage errors before an invocation. Error bodies and secrets never go to stdout. If local evidence persistence fails, a core-owned emergency record goes to stderr and the envelope references `stderr:<record_id>`; root must preserve stderr. Emergency corrections carry supersedes_record_id and prior_record_persistence, so an earlier persisted success cannot silently remain authoritative. Complete disk failure cannot guarantee durable local storage and remains a stopped, explicitly weaker observation.

Python seam: `await readiness.invoke(input_value, transport=..., campaign_dir=...)`. `input_value` is a JSON string or object. Live transport is `transport.NativeAnthropic`; deterministic fixtures inject a transport implementing async `count`, async `create`, and `simulated`. Callers supply an already initialized campaign inside this trial folder. Transport implementations are trusted adapters, never model-selected plugins.

## Verification and first observations

The completed bounded offline suite is 91 tests at `offline-observations/run-9.txt`. Coverage is these declared controls only: input before provider calls; core tool correlation and denial; real local policy dispatch; identity stamping; whole parsing, ambiguity and diagnostics; task/citation invariants; attempt/tool/token/spend/deadline and prospective limits; native stop/content refusal behavior; unknown usage; actual async cancellation; evidence/error paths; JSONL readback; persistent campaign/lock controls; actual corrected-core imports; and native SDK serialization/no-retry behavior through an in-memory HTTP transport. The fixtures hard-code task results to test mechanisms. They are not evidence that a model understands readiness.

Run 1: 78 passing fixtures. Runs 2–4: the new native-SDK control failed while the previous 81 controls passed. SDK 1.8.0 does not accept a named `temperature` argument. The correction uses its supported `extra_body` argument, and the HTTP mock confirms the serialized JSON still has `temperature: 0`. Run 5: 82 passed. Run 6 adds actual cancellation/deadline, campaign invocation/concurrency and native HTTP500/no-retry controls: 89 passed. Run 7 reproduced two final root-review evidence seams: nested malformed usage could omit the attempt child, and a final campaign commit failure did not explicitly supersede the already persisted success. Both first failures were retained. Run 8 passes 91 controls after content-safe response projection and explicit emergency supersession. Run 9 passes the same 91 controls with the existing private-term hygiene test extended to a text prelude reused alongside a tool call; assistant history now uses the sanitized projection. Original logs and evidence were retained.

The native mock fixture's run-2 records incorrectly carry `simulated:false` because it inherited the live adapter class marker. These were in-memory mock observations, never real provider observations. From run 3 onward that fixture explicitly overrides the marker. The original records are preserved with this correction note. No original observation was rewritten. The fixture source/logs in early runs contain a fixed synthetic test token string; it was never a credential and no real key or authorization header was captured.

## Model judgment versus code

The model alone judges whether the brief explicitly supplies a user and benefit, an observable acceptance criterion, and internally consistent requirements. Code validates all three rule IDs occur once; the exact missing-ID set matches false assessments; ready means no missing IDs; citations use canonical statement IDs and exact nonempty substrings; and a claimed consistency conflict cites at least two distinct statements. These controls establish structural grounding, not semantic truth or injection resistance. Reasons can still be semantically wrong despite valid quotes.

The application owns canonical statement IDs. Supplied `[S<number>]` delimiters split the brief into nonempty statement chunks, then IDs are assigned sequentially from S1. Unmarked briefs are one S1 statement. This normalization is explicit in the user request sent to the model; original claimed IDs are not authoritative.

## Binding and constraints

`dependency-identity.json` pins the interpreter identity, 20-package active runtime dependency closure, actual source import, core version and all corrected-core source hashes. `requirements-lock.txt` is an identity record, not an installation instruction. The core remains external at `../corrected-candidate/agent_core_pkg/src`; no core mechanism is vendored. The native adapter checks version/source identity before obtaining the explicitly supplied environment key. Existing unrelated packages in the interpreter are not part of this dependency closure.

Native Messages uses the fixed direct endpoint, explicit API key, max_retries=0, no proxy environment, no redirects, no streaming, no cache, no fallback, no provider tools and no concurrency. Custom-header environment overrides are rejected. The first call forces get_policy. The final structured call retains the same tool definition with tool_choice none and native output_config. The SDK mock establishes local parameter/body compatibility; only an attended provider call can establish endpoint acceptance.

Each create reserves 201024 combined tokens and 205120 microdollars durably before dispatch. Usage is reconciled once through core Budget APIs. Failed/unknown usage retains that reservation and stops. Counting API calls are separately journaled before each model attempt; count failures dispatch no model call. At most 8000 preflight input tokens, 1024 output tokens per request, three model attempts, two actual local tools, and sixty seconds per invocation. The persistent shared campaign imposes eight invocations, twenty-four model attempts, sixteen tools, 500000 combined tokens, one dollar, and fifteen minutes. Prospective checks may stop earlier than those nominal maxima.

Core evidence uses an explicitly named UTC timestamp field; campaign deadlines persist epoch time and use monotonic remaining time within a process. Recorded shell-derived working date for this handoff: 2026-09-28, America/New_York. A wall-clock rollback before reopening state fails closed. Machine/process termination can leave an unresolved reservation; subsequent invocation stops rather than claiming completion or free usage.

## Limits and stopping point

No live semantic behavior has been measured; two public development cases and six held-out cases remain for the attended trial. PostgreSQL, orchestrators, side-effecting production tools, multi-provider portability, production deployment, cancellation after machine death, and hardened adversarial storage tamper resistance are outside this trial. The JSONL folder is a local evidence store, not a hardened audit service. Logical builder/evaluator separation uses one host and is not secrecy enforcement.

The emergency stderr evidence fallback is best effort if every writable surface fails. No task result survives that failure. The original portable evidence schema requires numeric usage even when usage is unknown; this binding retains unknown explicitly in core evidence instead of misrepresenting a reservation as measured usage. See `EVIDENCE-MAPPING.md` for the precise map and that representational limitation.

Stop here for root review and Tad's attended live launch. Do not turn offline control success into model-performance acceptance or install/publish this candidate.
