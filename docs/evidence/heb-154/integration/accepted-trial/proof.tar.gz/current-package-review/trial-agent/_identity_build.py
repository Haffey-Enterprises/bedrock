from pathlib import Path
import hashlib,importlib.metadata as md,json,sys
from pip._vendor.packaging.requirements import Requirement
ROOT=Path(__file__).resolve().parent
pending=['anthropic','jsonschema'];closure={};requires={}
while pending:
    name=pending.pop();dist=md.distribution(name);canonical=dist.metadata['Name']
    if canonical in closure:continue
    closure[canonical]=dist.version;requires[canonical]=[]
    for raw in dist.requires or []:
        req=Requirement(raw)
        if req.marker is None or req.marker.evaluate({'extra':''}):
            requires[canonical].append(str(req));pending.append(req.name)
core=ROOT.parent/'corrected-candidate'
manifest=json.loads((ROOT.parent/'correction-evidence/candidate-manifest.json').read_text())
source={str(p.relative_to(core)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((core/'agent_core_pkg/src/agent_core').glob('*')) if p.is_file() and p.suffix in ('.py','.typed')}
assert all(manifest[path]==sha for path,sha in source.items())
lock={'python_executable':sys.executable,'python_version':sys.version,'sdk_site_packages':str(Path(md.distribution('anthropic').locate_file(''))),'dependency_closure':dict(sorted(closure.items())),
 'active_requires':requires,'core_version':'0.2.0','core_import':str(core/'agent_core_pkg/src/agent_core/__init__.py'),'core_source_sha256':source,
 'test_interpreter':'/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-164-2026-09-23/linear-client-proof/venv/bin/python','pytest_version':'9.1.1',
 'import_order':['external corrected core src','trial-agent','SDK site-packages','interpreter stdlib'],
 'sdk_api_binding':'Messages native output_config; temperature is sent via extra_body because SDK1.8.0 omits named temperature parameter'}
(ROOT/'dependency-identity.json').write_text(json.dumps(lock,indent=2)+'\n')
(ROOT/'requirements-lock.txt').write_text('\n'.join(f'{k}=={v}' for k,v in sorted(closure.items()))+'\n# External corrected agent-core==0.2.0: see dependency-identity.json source hashes.\n')
# Input identity is not a claim to have read core tests; the read ledger lists scope separately.
(ROOT/'candidate-input-identity.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Pinned dependency closure:',len(closure),'distributions; external core source hashes verified.')
