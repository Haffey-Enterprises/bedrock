"""Bind this trial to the external corrected core, never a runtime's old core."""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
CORE_SRC = ROOT.parent / 'corrected-candidate' / 'agent_core_pkg' / 'src'
sys.path.insert(0, str(CORE_SRC))
import agent_core
if Path(agent_core.__file__).resolve() != CORE_SRC / 'agent_core' / '__init__.py':
    raise RuntimeError('corrected_core_import_mismatch')
