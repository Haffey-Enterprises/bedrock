# Ratified correction and trial scope

Recorded 2026-09-28, America/New_York, derived from native shell.

Operator: Tad. Exact authorization: “ratify R1-R3 with the live test after applying the fixes.” Subsequent steering: “let's do the live test together”.

R1, R2 and R3 in assessment.md are ratified individually as proposed. F1–F3 and the associated routine clarifications are authorized. proposed-trial.md defines the authorized bounded experiment, including synthetic content retention and budget. These source documents remain unchanged as proposal/review history.

Execution amendment: prepare and deterministically verify the corrected package and fresh builder output, then pause before any live API request. Present the first smoke input and expected behavior to Tad; run on his go and inspect evidence together before continuing. No autonomous live campaign. Original total call/spend limits remain ceilings, not a requirement to consume them. Human pauses do not authorize more calls or a silent extension of the stated elapsed limits; surface any elapsed-limit conflict before launch.

No provider-neutral adoption, fleet readiness, release acceptance or closure of the old campaign is asserted. Replacement scope is an explicit operator disposition, not a passing test result.

The corrected candidate is a copy of all 29 frozen input files; frozen inputs and archives remain the before-state. Implementation and test results are recorded separately.
