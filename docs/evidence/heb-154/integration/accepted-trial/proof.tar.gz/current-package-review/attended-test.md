# Attended live test — first smoke

Status: offline handoff review complete; ready for Tad’s go. No live provider request has been made. Tad requested that we run the live test together.

## First input

> [S1] A library member needs to see which books are overdue so they can return them.
>
> [S2] On the Loans page, each loan with a due date before today displays the exact label Overdue; all other loans display no overdue label.

Policy: readiness-v1, with three rules: explicit user-visible objective, observable acceptance criterion, and no contradictory requirements.

**Expected result: ready**, with no missing requirement IDs. The user and benefit are explicit; the labeling rule is observable; the statements do not conflict.

## What we inspect together

1. The model actually requests get_policy and the local tool actually executes.
2. The final response gives the expected judgment with grounded reasons and exact statement citations.
3. Invocation and child evidence agree with the requests, tool result, usage and terminal result.

A program-success status does not by itself establish a correct task judgment. Root scores task output independently. A failed live case stops the claim; no automatic retries or extra draws purchase a pass.

## Boundaries

Pinned direct Anthropic model claude-haiku-4-5-20251001. Synthetic content only. Maximum 8 invocations (2 development + 6 held-out), 24 physical model attempts, 16 tool dispatches, 500,000 combined tokens, and $1.00 total model spend. Each invocation has a 60-second ceiling; the live campaign has a 15-minute elapsed window. Interactive pauses remain inside that window. The 90-minute limit for the whole build/evaluate leg also remains in force; expiration must be surfaced, not silently reset.

On Tad's go, launch only this first smoke, then stop for joint inspection. The campaign has not been initialized. Offline fixture runs are separate and do not establish provider acceptance or task quality.
