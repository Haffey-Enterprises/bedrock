# agent-core 0.2.0

Mandatory shared substrate for every LLM-calling agent in the fleet.

See [USAGE.md](USAGE.md) and [DESIGN-NOTES.md](DESIGN-NOTES.md).

**Status**: untested in a real agent until the first proving run.
