# Shared Core Package

Placeholder only. The mandatory substrate is the separately supplied **agent-core** package (path dependency).

Do not populate this directory with a fork or copy of the implementation during an ordinary agent build.
If agent-core is unavailable, stop and surface the missing dependency.

See agent-core USAGE.md and DESIGN-NOTES.md for the public API and ratified decisions (C1–C7).
