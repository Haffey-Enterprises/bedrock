"""Independent task-result checks; qualitative grounding requires root/Tad review."""
import json
import re
import sys
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parent.parent
SCHEMA = json.loads((ROOT / "trial-agent/schemas/return-1.0.0.json").read_text())
RULES = {"R-OBJECTIVE", "R-ACCEPTANCE", "R-CONSISTENCY"}


def evaluate(case, envelope):
    failures = []
    if not Draft202012Validator(SCHEMA).is_valid(envelope):
        return {"structural_pass": False, "failures": ["return_schema"], "grounding": "requires_human_review"}
    if envelope["terminal_disposition"] != "success":
        return {"structural_pass": False, "failures": ["execution_failed"], "grounding": "not_scored"}
    if not envelope["invocation_id"] or not envelope["evidence_ref"]:
        failures.append("missing_identity_or_evidence_reference")
    task = envelope["task_result"]
    expected = set(case["expected_missing"])
    if task["readiness"] != case["expected_readiness"]:
        failures.append("wrong_readiness")
    if set(task["missing_requirement_ids"]) != expected:
        failures.append("wrong_missing_ids")
    assessments = task["assessments"]
    if len(assessments) != 3 or {x["rule_id"] for x in assessments} != RULES:
        failures.append("rule_population")
    parts = re.split(r"\[(S[1-9][0-9]*)\]", case["input"]["brief"])
    statements = dict(zip(parts[1::2], (x.strip() for x in parts[2::2])))
    for a in assessments:
        if a["met"] != (a["rule_id"] not in expected):
            failures.append("wrong_rule_assessment:" + a["rule_id"])
        for citation in a["citations"]:
            statement = statements.get(citation["statement_id"])
            if statement is None or citation["quote"] not in statement:
                failures.append("unsupported_quote:" + a["rule_id"])
        if case["case_id"] == "eval-conflict" and a["rule_id"] == "R-CONSISTENCY":
            if not {"S2", "S3"} <= {x["statement_id"] for x in a["citations"]}:
                failures.append("conflict_missing_both_statements")
    return {"structural_pass": not failures, "failures": failures,
            "grounding": "requires_human_review"}


if __name__ == "__main__":
    cases = json.loads((Path(__file__).parent / "cases.json").read_text())
    case = next(x for x in cases if x["case_id"] == sys.argv[1])
    print(json.dumps(evaluate(case, json.loads(Path(sys.argv[2]).read_text())), indent=2))
