# Cross-set synthetic probe commands and observed output

Retained from this review's tool transcript; commands were not rerun for administrative retention. Each command exited 0. Only stdout is reproduced below, without the execution tool's timing and chunk metadata.

## Frozen population and parsing controls

```sh
PYTHONDONTWRITEBYTECODE=1 /private/tmp/heb178-validation/bin/python - <<'PY'
import sys, json, hashlib
from pathlib import Path
root = Path('/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review')
manifest = json.loads((root/'input-manifest.json').read_text())
actual = sorted(str(p.relative_to(root/'inputs')) for p in (root/'inputs').rglob('*') if p.is_file())
listed = sorted(x['path'] for x in manifest)
print('manifest_population_match', actual == listed, 'manifest_files', len(listed), 'actual_files', len(actual))
print('hash_checks', [(x['path'], len((root/'inputs'/x['path']).read_bytes()) == x['bytes'] and hashlib.sha256((root/'inputs'/x['path']).read_bytes()).hexdigest() == x['sha256']) for x in manifest])
sys.path.insert(0,str(root/'inputs/agent_core_pkg/src'))
import agent_core
from agent_core import parse_structured, StructuredOutputError
print('imported',agent_core.__file__)
schema = {'type':'object','properties':{'answer':{'type':'string'}},'required':['answer'],'additionalProperties':False}
for label,raw in [('compact_control','{"answer":"yes"}'),('newline','{"answer":"yes"}\n'),('outer_whitespace',' {"answer":"yes"} '),('padded_fence','```json\n  {"answer":"yes"}  \n```'),('distinct_occurrences_control','{"answer":"same"} then {"answer":"same"}'),('array_wrong_kind','[{"answer":"yes"}]')]:
    try:
        result=parse_structured(raw,schema)
        print(label, 'ACCEPT',result.parse_path.value,dict(result.data), 'public_fields', sorted(vars(result)))
    except StructuredOutputError as e:
        print(label,'REJECT',str(e),'public_fields',sorted(vars(e)))
PY
```

```text
manifest_population_match True manifest_files 29 actual_files 29
hash_checks [('agent-builder/HANDOFF.md', True), ('agent-builder/SKILL.md', True), ('agent-builder/reference/README.md', True), ('agent-builder/shared/README.md', True), ('agent-code/README.md', True), ('agent-code/SKILL.md', True), ('agent-code/reference/agent-core-0.1-binding.md', True), ('agent-code/reference/agent-execution.schema.json', True), ('agent-code/reference/anthropic-python-profile.md', True), ('agent-code/reference/mcp-server-authoring.md', True), ('agent_core_pkg/DESIGN-NOTES.md', True), ('agent_core_pkg/README.md', True), ('agent_core_pkg/USAGE.md', True), ('agent_core_pkg/pyproject.toml', True), ('agent_core_pkg/src/agent_core/__init__.py', True), ('agent_core_pkg/src/agent_core/budget.py', True), ('agent_core_pkg/src/agent_core/config.py', True), ('agent_core_pkg/src/agent_core/evidence.py', True), ('agent_core_pkg/src/agent_core/py.typed', True), ('agent_core_pkg/src/agent_core/security.py', True), ('agent_core_pkg/src/agent_core/structured.py', True), ('agent_core_pkg/src/agent_core/tools.py', True), ('agent_core_pkg/src/agent_core/types.py', True), ('agent_core_pkg/src/agent_core/version.py', True), ('agent_core_pkg/tests/test_budget.py', True), ('agent_core_pkg/tests/test_config.py', True), ('agent_core_pkg/tests/test_evidence_security.py', True), ('agent_core_pkg/tests/test_structured.py', True), ('agent_core_pkg/tests/test_tools.py', True)]
imported /Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/inputs/agent_core_pkg/src/agent_core/__init__.py
compact_control ACCEPT direct {'answer': 'yes'} public_fields ['data', 'parse_path', 'raw_text']
newline REJECT ambiguous structured output: 2 schema-valid candidates (paths: salvage_first_object, direct); uniqueness required public_fields ['parse_path']
outer_whitespace REJECT ambiguous structured output: 2 schema-valid candidates (paths: direct, salvage_first_object); uniqueness required public_fields ['parse_path']
padded_fence REJECT ambiguous structured output: 2 schema-valid candidates (paths: salvage_first_object, salvage_fence); uniqueness required public_fields ['parse_path']
distinct_occurrences_control REJECT ambiguous structured output: 2 schema-valid candidates (paths: salvage_first_object, salvage_first_object); uniqueness required public_fields ['parse_path']
array_wrong_kind ACCEPT salvage_first_object {'answer': 'yes'} public_fields ['data', 'parse_path', 'raw_text']
```

## Published usage sketch accounting

```sh
PYTHONDONTWRITEBYTECODE=1 /private/tmp/heb178-validation/bin/python - <<'PY'
from pathlib import Path
import sys
root=Path('/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/inputs')
sys.path.insert(0,str(root/'agent_core_pkg/src'))
from agent_core import CoreConfig
text=(root/'agent_core_pkg/USAGE.md').read_text()
sketch=text.split('```python\n',1)[1].split('```',1)[0]
sketch=sketch.replace('cfg = load_config("/path/to/agent_config.json")','cfg = CoreConfig()')
for label,body in [('valid_usage_control',sketch),('nonfinite_usage',sketch.replace('tokens=100, spend=0.001','tokens=100, spend=float("nan")'))]:
    scope={'CoreConfig':CoreConfig,'print':lambda *args:None}
    try:
        exec(compile(body,'USAGE.md example','exec'),scope)
        exception=None
    except Exception as e:
        exception=type(e).__name__
    record=scope['record']
    print(label,'exception',exception,'model_attempts',record.model_attempts,'disposition',record.disposition)
PY
```

```text
valid_usage_control exception None model_attempts 1 disposition success
nonfinite_usage exception ValueError model_attempts 2 disposition provider_error
```

## Public parse diagnostics

```sh
PYTHONDONTWRITEBYTECODE=1 /private/tmp/heb178-validation/bin/python - <<'PY'
from pathlib import Path
import sys
root=Path('/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/inputs')
sys.path.insert(0,str(root/'agent_core_pkg/src'))
from agent_core import parse_structured, StructuredOutputError
schema={'type':'object','properties':{'answer':{'type':'string'}},'required':['answer'],'additionalProperties':False}
for label,raw in [('schema_invalid','{"answer":17}'),('no_json','nonsense'),('invalid_then_valid','{"answer":17} then {"answer":"yes"}')]:
    try:
        result=parse_structured(raw,schema)
        print(label,'ACCEPT',{'data':result.data,'parse_path':result.parse_path.value,'fields':sorted(vars(result))})
    except StructuredOutputError as e:
        print(label,'REJECT',{'message':str(e),'parse_path':e.parse_path.value,'fields':sorted(vars(e))})
PY
```

```text
schema_invalid REJECT {'message': 'no schema-valid structured candidate found', 'parse_path': 'failed', 'fields': ['parse_path']}
no_json REJECT {'message': 'no schema-valid structured candidate found', 'parse_path': 'failed', 'fields': ['parse_path']}
invalid_then_valid ACCEPT {'data': {'answer': 'yes'}, 'parse_path': 'salvage_first_object', 'fields': ['data', 'parse_path', 'raw_text']}
```
