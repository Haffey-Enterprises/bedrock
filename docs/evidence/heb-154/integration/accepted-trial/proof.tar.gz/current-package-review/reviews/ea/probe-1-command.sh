PYTHONDONTWRITEBYTECODE=1 '/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-25/sdk-proof/venv/bin/python' -B - <<'PY'
from pathlib import Path
import sys,json
sys.path.insert(0,'/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/inputs/agent_core_pkg/src')
from agent_core import parse_structured, StructuredOutputError, Budget, ToolCapability, SideEffectClass, SecurityBoundary, AuthorizationError
schema={'type':'object','properties':{'answer':{'type':'string'}},'required':['answer'],'additionalProperties':False}
cases={'compact_control':'{"answer":"ok"}','leading_whitespace':' {"answer":"ok"}','trailing_newline':'{"answer":"ok"}\n','both_whitespace':'\n {"answer":"ok"}\n','fence_control':'```json\n{"answer":"ok"}\n```','indented_fence':'```json\n  {"answer":"ok"}\n```','two_occurrences_control':'{"answer":"ok"} then {"answer":"ok"}'}
for name,raw in cases.items():
 try:
  result=parse_structured(raw,schema)
  print(json.dumps({'case':name,'outcome':'accepted','path':result.parse_path.value}))
 except StructuredOutputError as exc:
  print(json.dumps({'case':name,'outcome':'rejected','message':str(exc)}))
for name in ('leading_whitespace','trailing_newline','both_whitespace'):
 result=parse_structured(cases[name],schema,allow_salvage=False)
 print(json.dumps({'case':name,'salvage':False,'outcome':'accepted','path':result.parse_path.value}))
b=Budget(max_model_attempts=3,max_tokens=100,max_spend=1)
b.check('model')
try:
 b.record_model_attempt(tokens=10,spend=float('nan'))
except ValueError:
 b.record_model_attempt(tokens=0,spend=0)
print(json.dumps({'case':'usage_error_using_sketch_exception_path','model_attempts':b.model_attempts,'tokens_used':b.snapshot().tokens_used,'spend_used':b.snapshot().spend_used}))
PY
