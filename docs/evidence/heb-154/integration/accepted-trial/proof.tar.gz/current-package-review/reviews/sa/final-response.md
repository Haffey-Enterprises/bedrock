Tad, I recommend correcting the parser before using this package in the proving agent. I found two reproducible correctness defects; the second is in the usage sketch’s error accounting.

```json
{
  "schema_version": "1.0.0",
  "kind": "reviewer_result",
  "invocation_id": "current-package-sa",
  "source": "codex-isolated-review",
  "stance": "SA",
  "findings": [
    {
      "id": "084b42228c323cc64f96b5d671d77040d08e3bb80e0990d4adbc1f68d0e59860",
      "severity": "MATERIAL",
      "targets": [
        "agent_core_pkg/src/agent_core/structured.py"
      ],
      "locus": "agent_core_pkg/src/agent_core/structured.py:186-205",
      "stance": "SA",
      "claim": "Whitespace around a single valid JSON object creates distinct direct/fence and balanced-object spans, so default parsing rejects one source occurrence as ambiguous. The candidate text is stripped while its span is left untrimmed; a trailing newline alone reproduces the failure.",
      "cited_authority": {
        "kind": "design-intent",
        "ref": "agent_core_pkg/DESIGN-NOTES.md: Structured output uniqueness; agent_core_pkg/USAGE.md:188; agent-code/SKILL.md: Structured output steps 2-4"
      },
      "status": "open",
      "related_finding_ids": []
    },
    {
      "id": "370e014cba1b605b7983613383c029ece4e8e1d4f7d749ec01c9b5b3ff8ae798",
      "severity": "MATERIAL",
      "targets": [
        "agent_core_pkg/USAGE.md"
      ],
      "locus": "agent_core_pkg/USAGE.md:85-98",
      "stance": "SA",
      "claim": "The exception-safe loop sketch counts a model attempt twice when usage reconciliation raises. record_model_attempt increments before rejecting invalid usage; the surrounding transport exception handler calls record_model_attempt again for the same attempted call, corrupting terminal evidence and consuming a second attempt.",
      "cited_authority": {
        "kind": "design-intent",
        "ref": "agent_core_pkg/DESIGN-NOTES.md: Budget consumption increments first; agent_core_pkg/src/agent_core/budget.py:172-182; agent-code/SKILL.md: One aggregate execution budget"
      },
      "status": "open",
      "related_finding_ids": []
    }
  ],
  "survived_attacks": [
    {
      "surface": "Synthetic spoofed fleet identity is stripped, trusted context replaces required identity, and absent project identity does not survive from model data.",
      "cited_authority": {
        "kind": "design-intent",
        "ref": "agent_core_pkg/DESIGN-NOTES.md: Structured output identity"
      }
    },
    {
      "surface": "Synthetic tool results reorder to request order; orphan IDs and name mismatches reject; an argument-sensitive authorizer runs again and denies target B after allowing A.",
      "cited_authority": {
        "kind": "canonical",
        "ref": "agent-code/SKILL.md: Tool-loop state machine; agent_core_pkg/DESIGN-NOTES.md: Security"
      }
    }
  ]
}
```

Read coverage: I read **all 29 files under the frozen `inputs/` population whole**, including all Python source, tests, documentation, schemas, and placeholder files. I also read the review profile, input manifest, and all six frozen review-authority files whole. No read was truncated. A filesystem-to-manifest comparison found exactly the same 29 paths; every byte length and SHA-256 matched. The control confirmed the known `structured.py` path was present. This covers the supplied package population, not historical packages, prior findings, repository implementation, provider integration, or an executed agent.

Both findings are defects against current declared behavior, not optional design preferences:

| Finding | Practical consequence | Smallest correction | Code-review assessment |
|---|---|---|---|
| `084b4222…` | Ordinary valid output ending in a newline fails parsing. Recovery can consume additional model budget unnecessarily or terminate an otherwise successful task. | Normalize candidate spans to the actual trimmed JSON occurrence; preserve separate source occurrences. Honor the declared whole-payload-first sequence. Add whitespace variants beside the existing uniqueness tests. | Correctness/conformance; high impact; high likelihood; high confidence; **recommend blocking**. |
| `370e014c…` | A malformed usage value produces two recorded attempts for one simulated provider step, compromising evidence accuracy and remaining-attempt accounting. | Separate transport failure accounting from reconciliation failure, ensuring exactly one attempt increment per attempted call. | Correctness; medium impact; low likelihood; high confidence; **does not independently block a bounded proving run if its adapter avoids this sketch defect**. |

The second reproduction injects invalid usage into the sketch’s reconciliation seam; its literal placeholder `spend=0.001` does not trigger the error. No live provider behavior or incidence rate is claimed.

I did not promote duplicate-key policy, richer parser diagnostics, or broader adapter completeness into findings. Those require additional contract interpretation or are outside these demonstrated defects. The package expressly delegates prospective provider limits and portable evidence adaptation; I did not treat that delegation itself as an implementation failure.

The result above was validated in memory against the frozen `design-review-result.schema.json`. Finding IDs are SHA-256 over UTF-8 compact, sorted-key JSON containing sorted targets, whitespace-normalized locus and claim, and stance.

Synthetic probe evidence follows. All probe blocks used this command, with the indicated Python body on standard input:

```sh
PYTHONDONTWRITEBYTECODE=1 '/private/tmp/heb178-validation/bin/python' -B -
```

The interpreter reported Python `3.12.14` and jsonschema `4.26.0`. Candidate imports were explicitly sourced from the frozen input directory. No installs, bytecode, file edits, live provider calls, or external writes occurred. The distributed pytest suite was read but not executed; pytest was unavailable in this interpreter. These probes are therefore focused evidence, not a package-wide passing-test claim.

Parser probe:

```python
import sys, importlib.metadata
sys.path.insert(0, '/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/inputs/agent_core_pkg/src')
from agent_core import *
print('python',sys.version.split()[0],'jsonschema',importlib.metadata.version('jsonschema'))
schema={'type':'object','properties':{'answer':{'type':'string'}},'required':['answer'],'additionalProperties':False}
for raw in ['{"answer":"x"}', ' {"answer":"x"} ', '{"answer":"x"}\n', '```json\n{"answer":"x"}\n```', '```json\n  {"answer":"x"}  \n```','{"answer":"x"} {"answer":"x"}']:
    try:
        r=parse_structured(raw,schema)
        print(repr(raw),'OK',r.parse_path.value)
    except Exception as e:
        print(repr(raw),type(e).__name__,str(e))
```

Output:

```text
python 3.12.14 jsonschema 4.26.0
'{"answer":"x"}' OK direct
' {"answer":"x"} ' StructuredOutputError ambiguous structured output: 2 schema-valid candidates (paths: direct, salvage_first_object); uniqueness required
'{"answer":"x"}\n' StructuredOutputError ambiguous structured output: 2 schema-valid candidates (paths: salvage_first_object, direct); uniqueness required
'```json\n{"answer":"x"}\n```' OK salvage_fence
'```json\n  {"answer":"x"}  \n```' StructuredOutputError ambiguous structured output: 2 schema-valid candidates (paths: salvage_first_object, salvage_fence); uniqueness required
'{"answer":"x"} {"answer":"x"}' StructuredOutputError ambiguous structured output: 2 schema-valid candidates (paths: salvage_first_object, salvage_first_object); uniqueness required
```

Attempt-accounting probe, reproducing the sketch’s nested exception handling with a valid control and invalid synthetic usage:

```python
import sys
sys.path.insert(0, '/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/inputs/agent_core_pkg/src')
from agent_core import Budget, TerminalDisposition
for spend in [0.001,float('nan')]:
    budget=Budget()
    disposition=TerminalDisposition.UNKNOWN
    try:
        try:
            raw='{"compliant": true, "findings": []}'
            budget.record_model_attempt(tokens=100, spend=spend)
        except Exception as transport_err:
            try:
                budget.record_model_attempt(tokens=0, spend=0.0)
            except ValueError:
                pass
            disposition=TerminalDisposition.PROVIDER_ERROR
            raise
    except ValueError:
        pass
    print('spend',spend,'physical_calls',1,'recorded_attempts',budget.model_attempts,'disposition',disposition.value)
```

Output:

```text
spend 0.001 physical_calls 1 recorded_attempts 1 disposition unknown
spend nan physical_calls 1 recorded_attempts 2 disposition provider_error
```

Here `physical_calls 1` is the probe’s label for **one simulated provider step**, not a network call. The valid control retains `unknown` because this isolated probe stops before the sketch’s success-classification branch.

Identity, correlation, and authorization controls:

```python
import sys
sys.path.insert(0, '/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/inputs/agent_core_pkg/src')
from agent_core import *
ctx={'agent_id':'trusted','session_id':'s','invocation_id':'i'}
print('identity',stamp_identity({'agent_id':'forged','project_id':'forged','answer':'ok'},ctx))
req=[ToolRequest('r1','echo',{}),ToolRequest('r2','echo',{})]
print('ordered',[r.request_id for r in correlate_results(req,[ToolResult('r2','echo',True,{}),ToolResult('r1','echo',True,{})])])
for result in [ToolResult('r3','echo',True,{}),ToolResult('r1','other',True,{})]:
    try:
        correlate_results(req,[result])
    except ToolLoopError as e:
        print('correlation rejection',str(e))
seen=[]
def auth(cap,args):
    seen.append(args['target'])
    if args['target']=='B':
        raise AuthorizationError('B denied')
    return 'token-A'
b=SecurityBoundary(authorizer=auth)
c=ToolCapability('write',{'type':'object'},side_effect=SideEffectClass.LOCAL)
for target in ['A','B']:
    try:
        print('authorization',target,b.authorize_tool(c,{'target':target}))
    except AuthorizationError as e:
        print('authorization',target,str(e))
print('callback targets',seen)
```

Output:

```text
identity {'answer': 'ok', 'agent_id': 'trusted', 'session_id': 's', 'invocation_id': 'i'}
ordered ['r1', 'r2']
correlation rejection result request_id 'r3' does not match any request
correlation rejection result name 'other' does not match request 'echo' for id 'r1'
authorization A token-A
authorization B B denied
callback targets ['A', 'B']
```
