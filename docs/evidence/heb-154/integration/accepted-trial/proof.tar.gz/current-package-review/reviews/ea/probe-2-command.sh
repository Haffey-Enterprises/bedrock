PYTHONDONTWRITEBYTECODE=1 '/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-25/sdk-proof/venv/bin/python' -B - <<'PY'
import sys,json
sys.path.insert(0,'/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/inputs/agent_core_pkg/src')
from agent_core import Budget
for label,spend in [('valid_usage_control',0.001),('invalid_usage_core_only_control',float('nan'))]:
 b=Budget()
 try:
  b.record_model_attempt(tokens=10,spend=spend)
  error=None
 except ValueError as e:
  error=type(e).__name__
 print(json.dumps({'case':label,'error':error,'model_attempts':b.model_attempts,'tokens_used':b.snapshot().tokens_used,'spend_used':b.snapshot().spend_used}))
PY
