# agent-core 0.1.0 — Usage for specialist agents

**Status**: untested in a real agent until the first proving run (see agent-builder/HANDOFF.md).

This package is the sole implementation of the mandatory substrate. Every LLM-calling agent must depend on it; do not re-implement these invariants.

**Evidence record is core-owned for v0.1.** Adapters map `EvidenceRecord.to_dict()` into PostgreSQL (or any external schema). The core does not implement a database layer.

## Install

```bash
pip install -e /path/to/agent_core_pkg
# runtime dependency: jsonschema>=4.17
```

Requires Python ≥ 3.10.

## Budget enforcement boundary

`Budget.check` admits based on **past** consumption. Configuring `max_spend` / `max_tokens` / `max_wall_seconds` does **not** by itself keep a one-call agent under the agreed bound.

The **provider adapter** must:

1. Pass a prospective remaining allowance into each provider call (tokens/spend/time).
2. Reconcile actual usage via `record_*` after the call (including failed transport).
3. **Not** emit `SUCCESS` if the reconciled snapshot is exhausted on shared limits, unless an explicit overshoot was ratified before the run.

If a provider cannot honor a chosen bound, surface that limitation before the trial.

## Minimal agent loop sketch (exception-safe)

```python
from agent_core import (
    Budget, BudgetExhausted,
    ToolRegistry, check_capability, correlate_results,
    parse_structured, stamp_identity, StructuredOutputError,
    InvocationContext, emit_evidence,
    SecurityBoundary, AuthorizationError,
    ToolCapability, ToolRequest, ToolResult,
    TerminalDisposition, ParsePath, SideEffectClass,
    load_config, CORE_VERSION, DEFAULT_IDENTITY_KEYS,
)

cfg = load_config("/path/to/agent_config.json")
ctx = InvocationContext(
    agent_id="standards-checker",
    session_id="sess-abc",
    project_id="proj-1",
    run_id="run-1",
    agent_version="0.1.0",
)
budget = cfg.make_budget()
registry = ToolRegistry([
    ToolCapability(
        name="lookup_standard",
        input_schema={
            "type": "object",
            "properties": {"id": {"type": "string"}},
            "required": ["id"],
            "additionalProperties": False,
        },
        side_effect=SideEffectClass.NONE,
    ),
])
boundary = SecurityBoundary(preauthorized={"lookup_standard"})

OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "compliant": {"type": "boolean"},
        "findings": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["compliant"],
    "additionalProperties": False,
}

disposition = TerminalDisposition.UNKNOWN
parse_path = None
final_payload = {}  # metadata-only by default

try:
    while True:
        budget.check("model")

        try:
            # --- provider adapter: pass remaining allowance; may raise ---
            # remaining_spend = budget.max_spend - budget.snapshot().spend_used
            raw = '{"compliant": true, "findings": []}'  # placeholder
            budget.record_model_attempt(tokens=100, spend=0.001)
        except Exception as transport_err:
            # Attempt happened or was attempted: count then classify
            try:
                budget.record_model_attempt(tokens=0, spend=0.0)
            except ValueError:
                pass
            disposition = TerminalDisposition.PROVIDER_ERROR
            final_payload = {"error": type(transport_err).__name__}
            raise

        try:
            result = parse_structured(
                raw, OUTPUT_SCHEMA, allow_salvage=cfg.allow_salvage
            )
            parse_path = result.parse_path
            data = stamp_identity(
                result.data,
                ctx.identity_map(),
                identity_keys=cfg.identity_keys,  # config controls output stamping
            )
            # Evidence provenance always comes from InvocationContext / emit_evidence;
            # identity_keys only affects which keys are stamped onto model output.
            snap = budget.snapshot()
            if snap.exhausted_shared() is not None:
                disposition = TerminalDisposition.BUDGET_EXHAUSTED
                final_payload = {"exhausted": snap.exhausted_shared(), "output_keys": list(data.keys())}
            else:
                disposition = TerminalDisposition.SUCCESS
                final_payload = {"output_keys": list(data.keys())}
            break
        except StructuredOutputError as e:
            parse_path = e.parse_path
            disposition = TerminalDisposition.PARSE_FAILED
            final_payload = {"parse_error": str(e)}
            break

except BudgetExhausted as e:
    disposition = TerminalDisposition.BUDGET_EXHAUSTED
    final_payload = {"exhausted": e.dimension}
except Exception:
    if disposition == TerminalDisposition.UNKNOWN:
        disposition = TerminalDisposition.PROVIDER_ERROR
    raise
finally:
    # Always emit terminal evidence (success, parse failure, budget, provider error)
    record = emit_evidence(
        ctx,
        disposition,
        parse_path=parse_path,
        budget_snapshot=budget.snapshot(),
        payload=final_payload,
    )
    # persist record.to_dict() via adapter — not done here

print(record.to_dict())
print("core_version:", CORE_VERSION)
```

## Tool dispatch

```python
requests = [
    ToolRequest(request_id="c1", name="lookup_standard", arguments={"id": "ISO-1"}),
]
results = []
for req in requests:
    budget.check("tool")
    budget.record_tool_iteration()
    cap = check_capability(registry, req.name, req.arguments)
    boundary.authorize_tool(cap, req.arguments)
    results.append(ToolResult(req.request_id, req.name, ok=True, content={"text": "..."}))

ordered = correlate_results(requests, results)
```

## File-controlled configuration

```json
{
  "allow_salvage": true,
  "budget": {
    "max_model_attempts": 6,
    "max_tool_iterations": 12,
    "max_tokens": 64000,
    "max_spend": 0.50,
    "max_wall_seconds": 120.0
  },
  "identity_keys": [
    "agent_id", "session_id", "invocation_id",
    "parent_invocation_id", "run_id", "project_id"
  ]
}
```

Unknown keys and non-finite numbers are rejected. `max_spend` is US dollars. Default `allow_salvage` is `true`.

## Salvage uniqueness

Candidates are identified by **source span** in the raw text. The same occurrence found via two paths (e.g. fence body and balanced scan) is one candidate. Two separate occurrences—even with identical bytes—are two candidates; if both are schema-valid → `PARSE_FAILED`.

`ParsePath.SALVAGE_FIRST_OBJECT` means balanced-object salvage (compatibility label); it does not require the chosen span to be the first object in document order when uniqueness selects the sole valid object.

## What this package deliberately does not do

- No model-provider SDKs (adapters own prospective call bounds and transport)
- No multi-agent orchestration
- No database / PostgreSQL client
- No parallelism, circuit breakers, or MCP negotiation

## Version

Record `agent_core.CORE_VERSION` (`"0.1.0"`) in the fleet interface and evidence records.
