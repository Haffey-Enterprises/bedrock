"""Package version. Recorded in every agent's fleet interface and evidence records."""

__version__ = "0.1.0"
CORE_VERSION = __version__
