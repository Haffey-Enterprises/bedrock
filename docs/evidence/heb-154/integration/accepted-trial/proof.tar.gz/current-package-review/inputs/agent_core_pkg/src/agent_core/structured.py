"""
Structured-output contract.

Pipeline (fixed order):
  1. Collect candidate JSON texts (direct + salvage grammar)
  2. Parse each; keep those that are objects and schema-valid
  3. Accept only if exactly one schema-valid candidate (uniqueness)
  4. Identity stamping from invocation context (never from model claims)
  5. Parse-path recording
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from typing import Any, Mapping, Optional, Sequence

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError, ValidationError

from agent_core.types import ParsePath

# Reserved identity keys: always stripped from model data before stamping.
RESERVED_IDENTITY_KEYS = frozenset(
    {
        "agent_id",
        "session_id",
        "invocation_id",
        "parent_invocation_id",
        "run_id",
        "project_id",
    }
)


class StructuredOutputError(Exception):
    """Raised when structured output cannot be obtained or fails schema/uniqueness."""

    def __init__(self, message: str, parse_path: ParsePath = ParsePath.FAILED):
        super().__init__(message)
        self.parse_path = parse_path


@dataclass
class ParseResult:
    """Successful structured parse with provenance."""

    data: Mapping[str, Any]
    parse_path: ParsePath
    raw_text: str


# ---------------------------------------------------------------------------
# Schema validation via jsonschema (Draft 2020-12)
# ---------------------------------------------------------------------------

def _reject_non_finite(obj: Any, path: str = "$") -> None:
    """Reject NaN / ±Inf that can appear after non-strict decoding paths."""
    if isinstance(obj, float) and not math.isfinite(obj):
        raise StructuredOutputError(
            f"{path}: non-finite number {obj!r} is not allowed",
            ParsePath.FAILED,
        )
    if isinstance(obj, dict):
        for k, v in obj.items():
            _reject_non_finite(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            _reject_non_finite(v, f"{path}[{i}]")


def _make_validator(schema: Mapping[str, Any]) -> Draft202012Validator:
    try:
        Draft202012Validator.check_schema(schema)
    except SchemaError as e:
        raise StructuredOutputError(
            f"invalid schema: {e.message}",
            ParsePath.FAILED,
        ) from e
    return Draft202012Validator(schema)


def _validate(instance: Any, schema: Mapping[str, Any]) -> None:
    _reject_non_finite(instance)
    validator = _make_validator(schema)
    errors = sorted(validator.iter_errors(instance), key=lambda e: list(e.path))
    if errors:
        e = errors[0]
        path = "$"
        if e.absolute_path:
            path = "$." + ".".join(str(p) for p in e.absolute_path)
        raise StructuredOutputError(
            f"{path}: {e.message}",
            ParsePath.FAILED,
        )


# ---------------------------------------------------------------------------
# Candidate extraction (direct + salvage grammar)
# ---------------------------------------------------------------------------

_FENCE_RE = re.compile(
    r"```(?:json)?\s*\n?(.*?)\n?```",
    re.DOTALL | re.IGNORECASE,
)


def _try_json(text: str) -> Optional[Any]:
    text = text.strip()
    if not text:
        return None
    try:
        # strict: reject NaN/Infinity from the decoder
        return json.loads(text, parse_constant=lambda c: (_ for _ in ()).throw(
            json.JSONDecodeError(f"non-finite constant {c!r}", text, 0)
        ))
    except (json.JSONDecodeError, ValueError):
        return None


def _extract_all_object_spans(text: str) -> list[tuple[int, int]]:
    """Return (start, end) spans of every top-level balanced {...} (end exclusive)."""
    results: list[tuple[int, int]] = []
    i = 0
    while i < len(text):
        start = text.find("{", i)
        if start < 0:
            break
        depth = 0
        in_string = False
        escape = False
        end = None
        for j, ch in enumerate(text[start:], start=start):
            if in_string:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_string = False
                continue
            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    end = j + 1
                    break
        if end is not None:
            results.append((start, end))
            i = end
        else:
            break
    return results


@dataclass(frozen=True)
class _Candidate:
    text: str
    path: ParsePath
    data: Any
    span: tuple[int, int]


def _collect_candidates(raw_text: str, *, allow_salvage: bool) -> list[_Candidate]:
    """
    Build the candidate set under the salvage grammar.

    Candidates are keyed by source span (start, end) in raw_text so that the
    same occurrence discovered via two paths collapses to one candidate, while
    two separate occurrences (even with identical text) remain distinct.
    Path label priority when collapsing: direct > fence > balanced-object.
    """
    # span -> candidate (first/highest-priority path wins)
    by_span: dict[tuple[int, int], _Candidate] = {}
    path_rank = {
        ParsePath.DIRECT: 0,
        ParsePath.SALVAGE_FENCE: 1,
        ParsePath.SALVAGE_FIRST_OBJECT: 2,
    }

    def add(span: tuple[int, int], text: str, path: ParsePath) -> None:
        key_text = text.strip()
        if not key_text:
            return
        data = _try_json(key_text)
        if data is None:
            return
        cand = _Candidate(text=key_text, path=path, data=data, span=span)
        prev = by_span.get(span)
        if prev is None or path_rank[path] < path_rank[prev.path]:
            by_span[span] = cand

    add((0, len(raw_text)), raw_text, ParsePath.DIRECT)

    if allow_salvage:
        for m in _FENCE_RE.finditer(raw_text):
            # group 1 is fence body; span is body span in raw_text
            add((m.start(1), m.end(1)), m.group(1), ParsePath.SALVAGE_FENCE)
        for span in _extract_all_object_spans(raw_text):
            add(span, raw_text[span[0] : span[1]], ParsePath.SALVAGE_FIRST_OBJECT)

    # Stable order: by span start
    return [by_span[s] for s in sorted(by_span.keys(), key=lambda s: (s[0], s[1]))]


def parse_structured(
    raw_text: str,
    schema: Mapping[str, Any],
    *,
    allow_salvage: bool = True,
) -> ParseResult:
    """
    Execute the mandatory structured-output pipeline.

    Uniqueness rule (ratified): among all candidates produced by the grammar,
    exactly one must be a JSON object that validates against `schema`.
    Zero or two-or-more schema-valid candidates → StructuredOutputError.
    """
    if not isinstance(raw_text, str):
        raise StructuredOutputError(
            f"raw_text must be str, got {type(raw_text).__name__}",
            ParsePath.FAILED,
        )

    # Validate schema early so bad contracts fail closed
    _make_validator(schema)

    candidates = _collect_candidates(raw_text, allow_salvage=allow_salvage)

    valid: list[_Candidate] = []
    for cand in candidates:
        if not isinstance(cand.data, dict):
            continue
        try:
            _validate(cand.data, schema)
        except StructuredOutputError:
            continue
        valid.append(cand)

    if len(valid) == 0:
        raise StructuredOutputError(
            "no schema-valid structured candidate found",
            ParsePath.FAILED,
        )
    if len(valid) > 1:
        paths = ", ".join(f"{c.path.value}" for c in valid)
        raise StructuredOutputError(
            f"ambiguous structured output: {len(valid)} schema-valid candidates "
            f"(paths: {paths}); uniqueness required",
            ParsePath.FAILED,
        )

    chosen = valid[0]
    return ParseResult(data=chosen.data, parse_path=chosen.path, raw_text=raw_text)


def stamp_identity(
    data: Mapping[str, Any],
    context: Mapping[str, Any],
    *,
    identity_keys: Sequence[str] = (
        "agent_id",
        "session_id",
        "invocation_id",
        "parent_invocation_id",
        "run_id",
        "project_id",
    ),
) -> dict[str, Any]:
    """
    Stamp identity fields from invocation context onto the parsed object.

    Reserved identity keys are always removed from model data first, then
    trusted context values are written. Model claims never survive.
    """
    out: dict[str, Any] = {
        k: v for k, v in data.items() if k not in RESERVED_IDENTITY_KEYS
    }
    for key in identity_keys:
        if key in context:
            out[key] = context[key]
        elif key in RESERVED_IDENTITY_KEYS:
            # Explicit absence: do not leave a model value; key omitted
            out.pop(key, None)
    return out
