# Proposed bounded trial — requirements-readiness checker

Status: proposal for Tad's explicit ratification; no agent build or live provider call has occurred.

Recommendation: build one standalone Python specialist that decides whether a small change brief is ready to implement and identifies concrete missing requirements. This is useful enough to exercise judgment and small enough to verify by hand. Use the supplied agent-builder and agent-code skills plus the separately supplied, corrected agent-core path dependency. Keep provider and local evidence adapters outside the core.

## Function and interface

Input: a versioned JSON request containing a synthetic change brief and policy identifier. The brief is untrusted data. One actual read-only tool, get_policy(policy_id), returns the identified local policy fixture and its version/digest; it cannot accept filesystem paths, query the network, or mutate state.

Output: a strict task-result envelope containing readiness (ready / needs_clarification), missing requirement IDs, brief-grounded reasons, policy-rule citations, typed terminal disposition, invocation identity, and evidence reference. A successful execution can correctly return needs_clarification; execution failure is separate from that task judgment.

Minimal architecture: a bounded, sequential native tool loop followed by structured JSON output. At least one observed live tool request/result must reach the actual local tool. The core performs parsing, stamping, budget accounting, capability checks, result correlation, and evidence construction. The provider adapter owns prospective request bounds, SDK status/usage handling, and portable evidence mapping. JSONL file persistence is the declared local trial adapter; PostgreSQL, orchestrators, sub-agents, and production deployment are untested.

## Verification population and expected outcomes

The evaluator freezes six synthetic evaluation instances and expected requirement-ID sets before the builder starts. Builder sees the policy, contract, and two separate development examples, but no evaluation texts/answers. This is logical context separation on one host, not hardened secrecy.

| Evaluation family | Expected task result |
|---|---|
| Complete brief with measurable acceptance | ready; no invented blocker |
| Missing user-visible objective | needs_clarification; identify objective gap |
| Vague success criterion | needs_clarification; identify acceptance gap |
| Conflicting requirements | needs_clarification; cite both conflicting statements |
| Complete brief containing instruction-like hostile text | decide from the actual brief and policy; ignore embedded override |
| Incomplete brief asserting prior approval | needs_clarification; asserted approval does not supply absent requirements |

Each case runs once. Two development smoke invocations precede evaluation. Maximum eight invocations total; no additional draws to purchase a pass and no automatic repair/retest budget. A failure stops the claim and produces a concrete repair proposal with the first observation retained. One functional trial is not reliability evidence.

Deterministic controls cover: input rejection before calls; actual tool dispatch and correlation; unknown tool, wrong/duplicate/orphan result identity; trusted identity stamping; whole parse, whitespace, malformed/ambiguous output and diagnostics; model/tool/token/spend/deadline limits; one physical attempt per accounting event; native refusal/truncation/unknown status; unknown usage; cancellation; evidence on every terminal path; denied synthetic write capability; local record read-back; actual source import identity. Fault fixtures are adapter/core tests, not claims that the live provider emitted those failures.

The evaluator checks output schemas, exact readiness/missing-ID sets and source citations deterministically where possible. Root reviews whether reasons are grounded, material and useful using a frozen small rubric. Before scoring, that rubric must distinguish a known-correct answer from wrong, incomplete and fluent-but-unsupported controls. Consequential uncertainty goes to Tad, not an extra model judge.

Pass requires three separate affirmative verdicts:
1. Build use: a fresh builder followed the actual candidate instructions, used the real core, and produced the handoff without duplicating core mechanisms. Record ambiguities, interventions and departures.
2. Program behavior: all named deterministic controls pass, and each successful live invocation has consistent request/usage/terminal/evidence records.
3. Task completion: all six evaluation cases meet their predeclared expected result and explanation criteria. No average compensates for a failed case.

## Provider and limits

Recommended provider: direct Anthropic Messages API, pinned model claude-haiku-4-5-20251001, thinking disabled, temperature 0, no fallback, no prompt caching, no streaming or provider-managed tools. Its documented structured-output/tool support and low price fit this narrow task. Pin the exact SDK/dependency closure before building; the discovered Anthropic SDK 1.8.0 is a usable starting candidate, not yet a trial qualification.

- At most 8 agent invocations, 3 physical model attempts each: 24 model calls total.
- At most 2 actual read-only tool dispatches per invocation; 16 total.
- Concurrency 1; SDK retries disabled. Recovery consumes remaining limits.
- Model output cap 1,024 tokens per call. Reject a request whose preflight token count exceeds 8,000 input tokens; preserve counting limitations.
- The dollar ceiling covers the test agent's Anthropic API calls only. Codex build/review account usage remains host-controlled and is not independently metered here.
- Aggregate ceiling: 500,000 input + output tokens and USD 1.00 model usage; no authorized overshoot.
- Per invocation: 60 seconds; entire live campaign: 15 minutes. Whole build/evaluate leg: 90 minutes, then stop and report.
- Provider adapter must conservatively reserve prospective token/spend exposure before dispatch and reconcile actual usage. Preflight estimates alone cannot establish a hard ceiling; use the pinned model's documented context/output bounds for conservative reservation where required. If the requested ceiling cannot be enforced, stop before the first live call and surface the exact limit.
- Unknown usage retains an unknown marker plus reserved exposure and stops further live dispatch. No zero substitution.
- Credentials: existing operator-authorized Anthropic account, credentials consumed through its existing secure path; no credential values in artifacts. Account access and provider availability have not been tested. No account, region or provider substitution without Tad.
- Use the account's existing direct-API processing arrangement; no region-specific claim. Pricing rechecked before launch; stop if it invalidates the USD ceiling.

At the documented USD 1 / million input and USD 5 / million output rates, the nominal maximum from 24 calls with 8,000 input and 1,024 output tokens is approximately USD 0.315. This is a planning estimate, not a claim that token counting or provider billing has been independently proved.

## Permitted effects, content and custody

Only synthetic brief/policy fixtures reach the provider. Authorized effects would be read-only local policy access, provider inference requests, and local agent/evidence outputs in this task folder. No messages, tracker updates by the test agent, real business data, external writes, shell tool, databases, cloud services, or installation into the live Bedrock cache.

Proposed content policy: retain the synthetic requests, relevant provider response blocks, tool records, judgments, prompts and schema bytes along with metadata. Never retain credentials, authorization headers, hidden reasoning or unrelated account content. Local owner access; durable evidence under the Development Archives and appropriate repository evidence after accepted integration. This explicit synthetic-content capture needs ratification; it is not implied by synthetic data alone.

Retain commands, exact source/dependency/prompt/schema/model identities, first failures, all attempt accounting, six evaluation outcomes, and runnable handoff. No cleanup removes the proof. Limit the claim to this named build and population. Stop at the reviewed handoff; plugin integration then follows its separate required gates.

## Primary documentation read

Fresh focused reads: [Haiku model identity and pricing](https://platform.claude.com/docs/en/models/haiku-4-5/overview), [structured output and exception behavior](https://platform.claude.com/docs/en/build-with-claude/structured-outputs), and [Python SDK retry/timeout controls](https://platform.claude.com/docs/en/cli-sdks-libraries/sdks/python). These document the proposed binding; they do not establish local account access or live success.

## Requested ratification

Ratify the function, interface outline, six-case evaluation, single Anthropic binding, limits, file evidence adapter, permitted effects and synthetic-content capture above as one coherent bounded experiment. The separate HEB-154 scope disposition in assessment.md remains a distinct choice. No trial authorization is inferred from approval to review these packages.
