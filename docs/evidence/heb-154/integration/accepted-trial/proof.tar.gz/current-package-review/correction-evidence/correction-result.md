# Correction result — ready for offline agent preparation

F1 (parser precedence), F2 (usage-example attempt accounting) and F3 (public diagnostics) are verified corrected on candidate-manifest.json identities. R3 parser safety is implemented with whole-only default, optional single outer fence, explicit best-effort scanning, duplicate rejection and byte/depth/candidate bounds. The Python implementation advances to 0.2.0 for the incompatible parser-default/mode change; the core-owned evidence shape remains v0.1 and the portable evidence schema version is separate.

Root executed the complete seven-file core test directory with no deselection: 57 tests passed. An independent finite check executed 35 targeted tests plus the original depth-bypass reproduction and shallow positive controls. This closes the named mechanism findings on the exact reviewed bytes, not whole-package acceptance or live-agent proof.

The first new regression test had a quoting syntax error during collection, before tests executed; the tool transcript and diagnosis retain that harness failure. After repair, 55 tests passed. Independent review then demonstrated that surrounding prose quote state could bypass the best-effort depth precheck. The parser now checks each extracted occurrence with fresh lexical state. The first failed depth observation, before/after hashes and reproduction are retained in closure-review.json; the original 55-test output and final 57-test output remain separate.

Original archives and all 29 input files remain unchanged; byte equality was checked for every non-directory archive member (agent-code 6, agent-builder 4, core 19). The 31-file candidate manifest includes two additional regression files and a renamed binding reference. No installed cache, dirty checkout, tracker, PR or release was changed by these corrections.

The builder is preparing the specialist offline using the actual corrected skill/core files. Six evaluator cases and expected outcomes were frozen before dispatch and are excluded from the builder context. No live API call has occurred. Tad requested attended testing; stop before token-count or generation calls, show the first smoke input/expectation, run on his go, and inspect evidence together. The original aggregate limits remain in force.

Proof limits: source execution under Python 3.14.6 with pytest 9.1.1/jsonschema 4.25.1; no clean wheel installation, minimum-Python matrix, live provider, task-judgment, PostgreSQL, concurrency or fleet-wide-readiness claim. Final agent gates and release/cold acceptance remain open.
