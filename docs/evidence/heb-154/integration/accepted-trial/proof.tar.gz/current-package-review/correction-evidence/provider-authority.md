# Focused provider authority for attended launch

Read depth: focused model identity/context/pricing and Python retry/timeout sections, not whole sites. These support the binding, not local account access or live acceptance.

- [Haiku 4.5 overview](https://platform.claude.com/docs/en/models/haiku-4-5/overview): exact direct-API snapshot claude-haiku-4-5-20251001; context200K tokens; input$1/million and output$5/million. Trial inference: reserving200000 input plus configured1024 output costs at most$0.20512 under these rates. This deliberately exceeds the request preflight estimate; reconcile actual usage and retain unknown exposure.
- [Python SDK](https://platform.claude.com/docs/en/cli-sdks-libraries/sdks/python): retry defaults include transient errors and timeouts; max_retries=0 disables them. Per-request timeout can override the long default. Root requires adapter cancellation/deadline enforcement in addition to these transport settings. Private SDK constructor arguments are qualified only against installed1.8.0, not a portable promise.
- [Define tools](https://platform.claude.com/docs/en/agents-and-tools/tool-use/define-tools): tool_choice none prevents further calls. Root recommendation: keep the tool definition with the existing tool history and use none in the final JSON phase. This is request-shape conformance reasoning, not an observed live rejection of the prior shape.
- [Handle tool calls](https://platform.claude.com/docs/en/agents-and-tools/tool-use/handle-tool-calls): tool results belong in user messages correlated to assistant tool_use IDs; failed execution needs an explicit error observation. The trial aborts on tool failure rather than retrying.

Actual SDK serialization is checked with an offline mock HTTP transport. Only the attended live test can establish provider acceptance and task behavior. No provider request was made while preparing this note.
