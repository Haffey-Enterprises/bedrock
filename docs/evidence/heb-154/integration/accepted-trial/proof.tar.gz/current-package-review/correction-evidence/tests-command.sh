#!/bin/sh
cd /private/tmp || exit 1
PYTHONDONTWRITEBYTECODE=1 '/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-164-2026-09-23/linear-client-proof/venv/bin/python' - <<'PY'
import sys,pathlib,importlib.metadata as m
p=pathlib.Path('/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-25/sdk-proof/venv/lib')
for d in p.glob('python*/site-packages'):sys.path.append(str(d))
src='/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/corrected-candidate/agent_core_pkg'
sys.path.insert(0,src+'/src')
import pytest,agent_core,jsonschema
print('Python:',sys.version)
print('Candidate:',agent_core.__file__)
print('Dependencies:', {n:m.version(n) for n in ['pytest','jsonschema','attrs','referencing','rpds-py','jsonschema-specifications']})
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','-o','addopts=',src+'/tests']))
PY
