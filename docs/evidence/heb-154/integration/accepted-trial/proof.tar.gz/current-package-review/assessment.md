# Current-package assessment and HEB-154 reconciliation

Recommendation: correct three demonstrated material defects, ratify a narrower proof profile explicitly, then run the bounded requirements-readiness checker trial. Do not integrate these exact bytes or close HEB-154 yet.

This is a completed multi-perspective assessment with open findings, not acceptance or mechanical convergence. The layers are coherent in principle: agent-code owns mechanism rules, agent-builder owns construction, and agent-core provides shared Python mechanisms with thin external adapters. The review does not require a general runtime, database service, orchestrator, or new proving platform.

## Subject, identities and read depth

Only the current supplied archives were assessed. Frozen copies and a complete member manifest are adjacent.

| Archive | Bytes | SHA-256 |
|---|---:|---|
| agent-code.zip | 9813 | ebd2a6cc60152c67beaf74e81bac5ccce420ccb5be5ee1b265e9ecf990f78e0c |
| agent-builder.zip | 9116 | 0a89deeb49e74a10ed42026e81928ca77c31fb2e3069698bcf50e77285d3314f |
| agent-core-0.1.0.zip | 26518 | d1200e89acc30311477488ab8d2a844f27b0b6d808e9651cb3a72c20a18fd1d7 |

All 29 non-directory members were inventoried and read whole by root and each reviewer: six agent-code, four agent-builder, nineteen agent-core (including all five test files). Bundled references, HANDOFF, USAGE, DESIGN-NOTES, schema, package metadata and every source file are included. Directory entries were inventoried separately. Member identity/population controls and configured-term hygiene checks passed; hygiene included a positive control. No old archive, installed-cache skill, or previous candidate implementation substituted for these inputs. Existing virtual environments supplied third-party interpreters/dependencies only.

Relevant repository authority was fetched from main commit 2ab76b447cdb1a975c801e6833682c0c1f94cef0: orientation, manifest and governance lifecycle read whole. The current manifest is 9.1.0; no next version is selected by this assessment. Frozen design-review/code-review skill text and result schema match main. Local checkout HEAD a9c40e7520b0f534e0b8686e4f2a24adf72cf1ed is on codex/heb-154-agent-code-v2-proving, with existing tracked and untracked work preserved. Its orientation has stale release ordering.

HEB-154 description and all five comments returned with hasNextPage=false were read whole. Canonical standard amendment and proving profile were read whole at the main commit. The ratification record was fetched whole but only its original seven dispositions and consumer-amendment sections were read; later business/custody detail was not read because this assessment does not resume that campaign. Package sibling routing references were not recursively treated as a requirement to audit all Bedrock skills.

Initial broad tool-discovery and ticket displays were truncated; discovery was narrowed and the ticket recovered in sections. A broad GitHub commit response also contained an unrelated truncated diff; only its identity fields were used, then relevant authorities were fetched at that identity. No whole-diff assessment is claimed. Official provider/MCP material was read in focused relevant sections, not whole websites.

## Review profile and arbitration

Four contexts were spawned with fork_turns=none: LAA, SA, EA, cross-set. They received identical frozen inputs and no prior or peer findings. Three ran concurrently; cross-set ran after a slot opened. Root arbitrated after independent results. Review tools were read-only with synthetic probes; later writes retained completed reviewer outputs only.

This applies design-review-loop isolation/arbitration principles proportionately. It is not a conforming runner-backed execution: no review runner, durable convergence gate, transport-budget harness or mechanical convergence claim. Host model/account limits and region were not independently observable; no additional metered provider requests were made. Full profile is in review-profile.md.

| Perspective | Admitted reviewer findings | Root relation |
|---|---:|---|
| LAA | 1 | Parser occurrence/precedence |
| SA | 2 | Parser; usage-example attempt accounting |
| EA | 2 | Same two defects, system consequences |
| Cross-set | 3 | Same two; unique public parse-diagnostics seam |

Eight reviewer assertions reduce to three distinct defects by explicit adjudicated merge. Raw results and IDs remain separate in reviews/. The parser defect appears in all four perspectives; accounting in three; diagnostics in cross-set only. Single-stance findings are not discarded. Root reproduced all three. No resolution or acceptance is claimed.

| ID / locus | Consequence | Smallest adequate correction | Arbitration |
|---|---|---|---|
| F1: agent_core_pkg/src/agent_core/structured.py:186–205,233–255 | A valid object plus one newline is counted as two valid candidates under default salvage. Normal output falsely fails and may consume retries. | Return a valid whole payload before salvage; canonicalize salvage spans to the actual trimmed JSON occurrence. Preserve rejection of two distinct identical occurrences. Add paired whitespace/fence controls. | MATERIAL, resolvable from current whole-first/source-occurrence contract; high confidence; blocks trial and integration. |
| F2: agent_core_pkg/USAGE.md:85–98; budget.py:172–182 | record_model_attempt increments before rejecting invalid usage; its encompassing transport handler increments again. One attempted call yields two recorded attempts. | Separate transport handling from reconciliation and count each physical attempt once. Retain an accounting-failure/unknown-usage indication; do not invent a second attempt. | MATERIAL, resolvable; high confidence, conditional trigger. Fix before distributing the primary example; no new runtime architecture required. |
| F3: agent_core_pkg/src/agent_core/structured.py:38–52,233–259; agent-code/SKILL.md:43 | Public results expose data/path/raw text and errors expose only path. Candidate counts and validation failures are lost, so the mandatory thin adapter cannot emit the required evidence without repeating core parsing. | Expose bounded, content-safe candidate and validation diagnostics on success and failure; let the adapter map those observations. Add tests for non-JSON, schema-invalid, mixed-candidate and ambiguous outputs. | MATERIAL, resolvable at obligation level; field naming is routine implementation. Do not reintroduce the old v2 envelope to solve this local seam. Blocks truthful combined evidence. |

Core review verdict: pause. These are demonstrated defects, not optional improvements. Proposed corrections preserve current stated intent and may be ratified together. No correction has been applied.

Separate ambiguities/clarifications:
- Binding should state object-only core parsing explicitly; portable array grammar is broader. Do not assume array support is required of the declared subset.
- Harmonize builder “exceeds” with the existing shared-limit “exhausts” predicate, including equality.
- Regeneration instructions supplement retained original execution metadata; rerunning does not recreate original history.
- HANDOFF still says findings 3–8 remain open without supplying their identities. That narration proves neither defects nor closure. Replace with the current assessed status after decisions, rather than inventing prior dispositions.
- Narrow “provider-neutral” and “injection containment” claims to stated requirements and observed evidence. MCP protocol negotiation must be distinguished from application-owned tool semantic versions.

Root additionally observed duplicate-key acceptance and a deeply nested response escaping as RecursionError. These are retained scope/safety questions against the old proving contract, not silently added current-package defects: the supplied subset does not declare the old duplicate/depth contract. The recommended safety disposition below resolves their treatment before trial.

## Executed verification and limits

All 37 tests shipped in agent_core_pkg/tests passed. Collection was the complete supplied tests directory, with no deselection and no inherited repository addopts. Root ran from /private/tmp, disabled bytecode and pytest cache, imported the frozen source explicitly, and installed nothing.

Environment: Python 3.14.6, pytest 9.1.1, jsonschema 4.25.1, attrs 26.1.0, referencing 0.37.0, rpds-py 2026.6.3, jsonschema-specifications 2025.9.1. Existing third-party dependency paths were combined explicitly; this was not a clean wheel installation or minimum-Python matrix. Review probes also ran on Python 3.12.14/jsonschema 4.26.0. Commands and observations are retained in assessment-evidence/ and reviews/.

Controls accept a compact object, reject two distinct valid occurrences, and expose failure only after whitespace is added. Valid usage records one attempt; injected invalid usage exposes the sketch's double count. Non-JSON and schema-invalid input collapse to the same generic error; successful salvage omits the rejected-candidate diagnostics. These scoped probes show why a passing shipped suite is insufficient.

| Gate | Disposition |
|---|---|
| Archive/member identity and hygiene | passed on the complete three-archive population |
| Whole current-package reads and four isolated review outputs | passed for the population declared above |
| Shipped core tests | passed, 37/37; no broader suite claim |
| Targeted current-contract controls | failed: F1–F3 |
| Agent build, live provider behavior and model task judgment | unavailable; intentionally awaiting ratification |
| Wheel/install, Python-version matrix, dependency security/license integration | unverified for release; not represented by source tests |
| Repository/package/routing/release/cold acceptance | not executed; candidate not integrated |
| PostgreSQL, concurrency, MCP runtime, provider-managed/write tools | outside proposed first trial; no proof claim |

## HEB-154 acceptance checklist

Current authorities still require the old Agent Code 2.0 envelope, three profiles and fulfillment-recovery campaign. The supplied archives use a v1 portable envelope, core-owned 0.1 evidence and a broader default salvage grammar. Latest task authorization selects these archives and a bounded real agent for assessment; it does not expressly disposition every old acceptance requirement.

No original AC2 obligation is marked closed by this packet. “Conflict” means a choice is required, not supersession.

| Criterion | Current evidence/status | Recommended next disposition |
|---|---|---|
| AC2-schema-negative | OPEN / representation conflict. Supplied schema is 1.0.0; frozen old invalid population not run. | Keep rejection of malformed/contradictory evidence, but explicitly replace exact v2 shape with bounded core-plus-adapter conformance if R1 is ratified. |
| AC2-schema-positive | OPEN / same conflict. Core suite is not whole old fixture proof. | Preserve valid model-only and one-model/one-tool positive controls under the chosen representation. |
| AC2-budget-joint | OPEN. Core tests cover selected limits; F2 and live adapter remain. | Fix F2; prove physical attempt accounting, prospective bounds, exact ceiling and unknown usage in trial. |
| AC2-terminal-truth | OPEN. Evidence emitter is a constructor, not a semantic success verifier; zero-attempt success can be constructed. | Application/adapter owns a deterministic terminal predicate; check no false success on malformed output, zero attempts, truncation, exhausted/unknown usage. Do not claim core alone verifies it. |
| AC2-side-effect-unknown | OPEN / scope conflict. Current subset lacks dedicated uncertainty/reconciliation mechanism. | Retain prohibition on unsafe retries; exclude side-effecting tools from first trial and explicitly leave write/reconciliation assurance unproved. |
| AC2-salvage-bounds | OPEN / policy conflict. F1; duplicate keys accepted; no parser resource ceiling; default embedded scanning. | Retain conservative load-bearing rule and safe parser bounds under R3; embedded salvage only when separately declared best-effort. |
| AC2-profile-complete | OPEN / scope conflict. One unpinned prose Anthropic profile; no three schema-bound profiles. | R1/R2 replace three-profile machinery with one exact trial binding plus explicit capability limits; no broad conformance claim. |
| AC2-profile-live | OPEN / scope conflict. No current live run. | R2 replaces LP01–LP09 × three providers with named single-provider live paths and separately labelled deterministic fault fixtures. |
| AC2-context-integrity | OPEN. Prompt-hash requirement exists; complete ordered request proof absent. | Retain trial-owned exact request, prompt/schema hashes and tool/result order; state provider-added-byte visibility limits. Do not require the old general manifest machinery if R1 passes. |
| AC2-provenance-total | OPEN. Focused current docs support proposal only; no total claim inventory. | Retain exact dependency/provider/protocol authority for claims made; replace broad campaign inventory only with explicit R1 disposition. |
| AC2-otel-pin | OPEN / scope conflict. Skill requires pinning if adopted; no exporter or mapping. | R1 excludes exporter/mapping proof from this release claim; retain metadata evidence and requirement to pin any future mapping. |
| AC2-routing | OPEN. Current descriptions read; no routing population executed. | Retain actual repository positive/negative/collision/prose routing checks when integrating agent-builder and amended agent-code. |
| AC2-consumer | OPEN / scope conflict. No builder or runtime trial. | R2 replaces old three-agent/two-provider/mixed campaign with proposed one-agent proof; separate build-use, program and task verdicts remain. |
| AC2-cold-review | OPEN. Four current-package reviews completed with defects; live/handoff reproduction not available. | Retain independent repaired-candidate reproduction, operator acceptance and HEB-119 release cold acceptance. |

Additional requested outcomes: current-package and implementation assessments are complete with pause verdicts; bounded test is designed but unratified; canonical plugin update and ticket closure remain conditional. Full normative bundle, migration, version selection, registry/compatibility/changelog/identities, release gates and rollout are still open.

## Decisions recommended for Tad, separately

R1 — Representation and proof apparatus: adopt the three-artifact architecture and a minimal, explicitly mapped core-owned record for this amendment, replacing the old prescribed v2 field layout, generation/profile YAML machinery, total provenance checker and OTel campaign as closure requirements. Retain truthful evidence, exact identities, negative/positive controls, budgets, fail-closed outcomes and independently reproducible observations. Rationale: preserve the safety properties without resurrecting an unused general proving system. Package/contract/core versions must be derived from the final delta; the Python library version is not the portable-contract version.

R2 — Claim and workload: replace the three-provider LP campaign and fulfillment-recovery/two-provider/mixed consumer gate with this named single-provider specialist trial. Explicitly withdraw provider-neutral adoption and fleet-wide readiness claims. Untested providers, writes/reconciliation, PostgreSQL, concurrency and orchestrators remain unproved. Rationale: matches the current request and yields useful empirical evidence at small cost; cannot support the former claim. This is an operator scope amendment, not a passing result for old obligations.

R3 — Parser safety: retain the previously ratified conservative rule for load-bearing output: whole parse, optionally one outer fence; reject duplicate keys and declared byte/depth-limit breaches with typed failure. Embedded scan belongs only to explicitly best-effort calls. Use whole-only mode in this trial. Rationale: selecting a plausible object from damaged/prose output should not silently authorize downstream decisions. This changes the supplied default/policy and therefore needs a distinct decision; it is not smuggled into F1.

R4 — Ratify the three current-contract corrections F1–F3 together, plus routine wording/status clarifications; then ratify the exact function, case population, provider, effects/content policy and budget in proposed-trial.md. Changes to R1–R3 are codified only after your explicit disposition.

## Canonical integration after successful agreed proof

Authoring source for distributed skills is plugins/bedrock/skills/, not an installed cache. Recommend a separate packages/agent-core source package with an exact dependency identity; final packaging/location is confirmed against current repository layout before edits. Preserve this dirty checkout and use a suitable isolated managed worktree from current main for integration.

Follow current repository governance: one feature-branch candidate transaction includes skill content and manifest bump; update registry, compatibility/migration, changelog, inventories and generated identities; run applicable deterministic, install/host, routing and review gates. Freeze the reviewed commit and pass HEB-119 cold acceptance before explicit proceed and merge. Land by merge commit with accepted source as second parent; prove marketplace/package byte equivalence; immutable tag/release at accepted source; retain rollout evidence. A successful single trial does not bypass those gates. HEB-161 remains the relevant bundled-release coordination surface and must be freshly reconciled at integration.

Only update/close HEB-154 when each applicable criterion is satisfied or explicitly dispositioned and retained. No tracker mutation, PR, merge, release, cache update or live trial occurred in this leg. Working evidence is retained here; durable archival and final workspace cleanup remain pending later acceptance, not silently performed.

Completed: whole current-package assessment, independent four-perspective review, scoped deterministic checks, current-authority reconciliation and trial proposal. Next concrete item: Tad's per-item R1–R3 scope/safety dispositions and approval of the coherent correction/trial packet.
