"""Ratified attended continuation: only the campaign wall-clock ceiling changes."""
import sys, json, hashlib
from pathlib import Path
AGENT = Path('/Users/thaffey/Documents/Haffey Enterprises/Working/HEB-154-2026-09-28/current-package-review/trial-agent')
sys.path.insert(0, str(AGENT))
import readiness
from identity import verify_binding
verify_binding()
manifest=json.loads((AGENT/'artifact-manifest.json').read_text())['sha256']
for name,wanted in manifest.items():
    if hashlib.sha256((AGENT/name).read_bytes()).hexdigest()!=wanted:
        raise RuntimeError('frozen_artifact_changed')
assert readiness.CONFIG['campaign']['max_wall_seconds']==900
readiness.CONFIG['campaign']['max_wall_seconds']=1800
from cli import main
if __name__=='__main__':sys.exit(main())
