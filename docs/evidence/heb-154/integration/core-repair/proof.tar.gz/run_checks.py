from pathlib import Path
import json, os, subprocess, sys
root=Path('/Users/thaffey/.codex/worktrees/heb-154-integration/bedrock')
work=Path(__file__).resolve().parent
base=work.parent/'integration'
label=sys.argv[1]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
env.pop('PYTHONPATH',None)
env.pop('ANTHROPIC_API_KEY',None)
if label in ('310','314'):
 python=str(work/('clean-'+label)/'venv/bin/python')
 commands=[('pytest-install',[python,'-I','-m','pip','install','pytest==9.1.1']),('core-installed',[python,'-I','-m','pytest','-v','-p','no:cacheprovider',str(root/'packages/agent-core/tests')])]
 if label=='314':
  commands += [('fixture-dependencies',[python,'-I','-m','pip','install','--require-hashes','--only-binary=:all:','-r',str(root/'tests/fixtures/agent-readiness/requirements-lock.txt')]),('offline-specialist',[python,str(root/'tests/fixtures/agent-readiness/run_offline_tests.py'),'--evidence-dir',str(work/'offline')])]
else:
 python=str(base/'venv/bin/python')
 commands=[('repository-unittest',[python,'-m','unittest','discover','-s','tests','-v']),('package-governance',[python,'scripts/validate_package_governance.py']),('strict-validation',[python,'scripts/validate_plugin.py','--inventory',str(work/'metadata-inventory.json')]),('strict-minimum',[str(base/'claude-minimum/node_modules/.bin/claude'),'plugin','validate',str(root/'plugins/bedrock'),'--strict']),('identity-check',[python,'scripts/sync_package_identity.py','--check']),('diff-check',['git','diff','--check'])]
results=[]
for name,cmd in commands:
 result=subprocess.run(cmd,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=label+'-'+name+'.txt'
 (work/log).write_text(result.stdout)
 results.append({'name':name,'command':cmd,'cwd':str(root),'returncode':result.returncode,'log':log})
 (work/(label+'-checks.json')).write_text(json.dumps(results,indent=2)+'\n')
 print(label,name,'exit',result.returncode,flush=True)
 if result.returncode:
  print(result.stdout,flush=True)
  raise SystemExit(result.returncode)
