import dataclasses, json, sys
from agent_core import Budget, StructuredOutputError, parse_structured
before = sys.argv[1] == "before"
budget=Budget(max_tokens=1)
try:
    budget.record_tokens(0.75)
    budget.record_tokens(0.75)
except ValueError:
    refused=True
else:
    refused=False
assert refused != before
assert budget.snapshot().tokens_used == 0
budget.check("model")
limits={}
for name in ("max_tokens", "max_model_attempts", "max_tool_iterations"):
    try:
        value=getattr(Budget(**{name:1.5}),name)
    except ValueError:
        value="refused"
    assert value == (1 if before else "refused")
    limits[name]=value
schema={"type":"object","properties":{"answer":{"type":"string"}},"required":["answer"],"additionalProperties":False}
payloads=[json.dumps({"answer":7})]*32+['{"answer":"valid"}']
raw="prefix\n"+"\n".join("```json\n  "+p+"  \n```" for p in payloads)
try:
    result=parse_structured(raw,schema,allow_salvage=True,best_effort=True)
    fenced=dataclasses.asdict(result.diagnostics)
except StructuredOutputError as e:
    fenced=dataclasses.asdict(e.diagnostics)
assert fenced["reason"] == ("candidate_limit" if before else "accepted")
control=parse_structured("prefix "+" ".join(payloads),schema,allow_salvage=True,best_effort=True)
assert control.diagnostics.candidate_count==33
assert control.diagnostics.schema_valid_count==1
print(json.dumps({"subject":sys.argv[1],"fractional_usage":{"refused":refused,"supplied_if_not_refused":1.5,"recorded":budget.snapshot().tokens_used,"admitted_after_recording_or_refusal":True},"fractional_limits":limits,"fenced":fenced,"unfenced_control":dataclasses.asdict(control.diagnostics)},indent=2))
